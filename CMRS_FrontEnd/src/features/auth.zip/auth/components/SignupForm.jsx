import { useState } from 'react';
import { motion } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { FiChevronDown, FiCheck, FiHome } from 'react-icons/fi';
import { ROUTES } from '../../../shared/navigation';
import PasswordInput from './PasswordInput';
import { registerUser } from '../api/authApi';
import GoogleAuthSection from './GoogleAuthSection';

const GOVERNORATE_OPTIONS = [
  { value: 'القاهرة', label: 'القاهرة' },
  { value: 'الجيزة', label: 'الجيزة' },
  { value: 'القليوبية', label: 'القليوبية' },
];

const initialValues = {
  fullName: '',
  phone: '',
  email: '',
  city: '',
  password: '',
  confirmPassword: '',
  termsAccepted: false,
};

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.08,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 22 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: [0.22, 1, 0.36, 1],
    },
  },
};

const GENERIC_VALIDATION_MESSAGES = new Set([
  'Validation failed.',
  'Validation failed',
]);

function normalizeArabicDigits(value) {
  return String(value || '')
    .replace(/[٠-٩]/g, (digit) => '٠١٢٣٤٥٦٧٨٩'.indexOf(digit))
    .replace(/[۰-۹]/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit));
}

function normalizePhoneForValidation(value) {
  return normalizeArabicDigits(value).replace(/[\s()+-]/g, '');
}

function addUniqueMessage(messages, message) {
  const normalizedMessage = String(message || '')
    .replace(/^\s*[-•]\s*/, '')
    .trim();

  if (normalizedMessage && !messages.includes(normalizedMessage)) {
    messages.push(normalizedMessage);
  }
}

function collectMessages(value, messages) {
  if (!value) {
    return;
  }

  if (Array.isArray(value)) {
    value.forEach((item) => collectMessages(item, messages));
    return;
  }

  if (typeof value === 'object') {
    Object.values(value).forEach((item) => collectMessages(item, messages));
    return;
  }

  String(value)
    .split(/\r?\n|\\r?\\n/)
    .forEach((item) => addUniqueMessage(messages, item));
}

function parsePossibleJson(value) {
  if (typeof value !== 'string') {
    return null;
  }

  const trimmedValue = value.trim();

  if (!trimmedValue.startsWith('{') && !trimmedValue.startsWith('[')) {
    return null;
  }

  try {
    return JSON.parse(trimmedValue);
  } catch {
    return null;
  }
}

function getApiErrorMessages(error) {
  const messages = [];
  const responseData = error?.response?.data;
  const directData = error?.data;

  collectMessages(responseData?.errors, messages);
  collectMessages(directData?.errors, messages);
  collectMessages(error?.errors, messages);

  const parsedErrorMessage = parsePossibleJson(error?.message);
  if (parsedErrorMessage) {
    collectMessages(parsedErrorMessage?.errors || parsedErrorMessage, messages);
  }

  if (messages.length === 0) {
    collectMessages(responseData?.message, messages);
    collectMessages(directData?.message, messages);
    collectMessages(error?.message, messages);
  }

  const usefulMessages = messages.filter(
    (message) => !GENERIC_VALIDATION_MESSAGES.has(message)
  );

  if (usefulMessages.length > 0) {
    return usefulMessages;
  }

  if (messages.some((message) => GENERIC_VALIDATION_MESSAGES.has(message))) {
    return [
      'تعذر إنشاء الحساب بسبب وجود بيانات غير صحيحة. راجع الحقول وحاول مرة أخرى.',
    ];
  }

  return ['حدث خطأ أثناء إنشاء الحساب. حاول مرة أخرى.'];
}

function SignupForm() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState(initialValues);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [visiblePasswords, setVisiblePasswords] = useState({
    password: false,
    confirmPassword: false,
  });
  const [errorMessages, setErrorMessages] = useState([]);
  const [isCityMenuOpen, setIsCityMenuOpen] = useState(false);

  const selectedCity = GOVERNORATE_OPTIONS.find(
    (city) => city.value === formData.city
  );

  function clearErrors() {
    if (errorMessages.length > 0) {
      setErrorMessages([]);
    }
  }

  function handleChange(event) {
    const { name, value, type, checked } = event.target;

    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));

    clearErrors();
  }

  function handleCitySelect(city) {
    setFormData((prev) => ({
      ...prev,
      city: city.value,
    }));

    setIsCityMenuOpen(false);
    clearErrors();
  }

  function validateForm() {
    const errors = [];
    const fullName = formData.fullName.trim();
    const phone = normalizePhoneForValidation(formData.phone);
    const email = formData.email.trim();
    const password = formData.password;
    const confirmPassword = formData.confirmPassword;
    const nameParts = fullName.split(/\s+/).filter(Boolean);
    const isKnownGovernorate = GOVERNORATE_OPTIONS.some(
      (option) => option.value === formData.city
    );

    if (!fullName) {
      errors.push('الاسم الكامل مطلوب.');
    } else {
      if (fullName.length < 3) {
        errors.push('الاسم الكامل يجب ألا يقل عن 3 أحرف.');
      }

      if (fullName.length > 100) {
        errors.push('الاسم الكامل يجب ألا يزيد على 100 حرف.');
      }

      if (!/^[\p{L}\p{M}][\p{L}\p{M}\s.'’-]*$/u.test(fullName)) {
        errors.push('الاسم الكامل يجب أن يحتوي على حروف فقط دون أرقام أو رموز غير مناسبة.');
      }

      if (nameParts.length < 2) {
        errors.push('اكتب الاسم الكامل مكوّنًا من اسمين على الأقل.');
      }
    }

    if (!formData.phone.trim()) {
      errors.push('رقم الهاتف مطلوب.');
    } else if (!/^01[0125]\d{8}$/.test(phone)) {
      errors.push('رقم الهاتف يجب أن يكون رقم موبايل مصريًا صحيحًا مكوّنًا من 11 رقمًا.');
    }

    if (!email) {
      errors.push('البريد الإلكتروني مطلوب.');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      errors.push('أدخل بريدًا إلكترونيًا صحيحًا، مثل name@example.com.');
    } else if (email.length > 254) {
      errors.push('البريد الإلكتروني طويل جدًا.');
    }

    if (!formData.city.trim()) {
      errors.push('اختر المحافظة.');
    } else if (!isKnownGovernorate) {
      errors.push('المحافظة المختارة غير متاحة.');
    }

    if (!password) {
      errors.push('كلمة المرور مطلوبة.');
    } else {
      if (password.length < 8) {
        errors.push('كلمة المرور يجب ألا تقل عن 8 أحرف.');
      }

      if (password.length > 100) {
        errors.push('كلمة المرور يجب ألا تزيد على 100 حرف.');
      }

      if (!/[a-z]/.test(password)) {
        errors.push('كلمة المرور يجب أن تحتوي على حرف إنجليزي صغير واحد على الأقل.');
      }

      if (!/[A-Z]/.test(password)) {
        errors.push('كلمة المرور يجب أن تحتوي على حرف إنجليزي كبير واحد على الأقل.');
      }

      if (!/\d/.test(password)) {
        errors.push('كلمة المرور يجب أن تحتوي على رقم واحد على الأقل.');
      }

      if (!/[^A-Za-z0-9\s]/.test(password)) {
        errors.push('كلمة المرور يجب أن تحتوي على رمز خاص واحد على الأقل، مثل @ أو #.');
      }

      if (/\s/.test(password)) {
        errors.push('كلمة المرور يجب ألا تحتوي على مسافات.');
      }
    }

    if (!confirmPassword) {
      errors.push('تأكيد كلمة المرور مطلوب.');
    } else if (password !== confirmPassword) {
      errors.push('كلمة المرور وتأكيدها غير متطابقين.');
    }

    if (!formData.termsAccepted) {
      errors.push('يجب الموافقة على الشروط والأحكام أولًا.');
    }

    return errors;
  }

  async function handleSubmit(event) {
    event.preventDefault();

    const validationErrors = validateForm();

    if (validationErrors.length > 0) {
      setErrorMessages(validationErrors);
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMessages([]);

      const response = await registerUser(formData);

      if (response?.success === false) {
        const responseError = new Error(
          response.message || 'حدث خطأ أثناء إنشاء الحساب.'
        );
        responseError.data = response;
        throw responseError;
      }

      navigate(ROUTES.LOGIN, {
        replace: true,
        state: {
          email: formData.email,
          message:
            response?.message ||
            'تم إنشاء الحساب بنجاح. يمكنك الآن تسجيل الدخول.',
        },
      });
    } catch (error) {
      setErrorMessages(getApiErrorMessages(error));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <motion.div
      className="signup-form"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.header className="signup-form__header" variants={itemVariants}>
        <h1 className="signup-form__title">انضم إلينا</h1>
        <p className="signup-form__lead">كن جزءًا من التغيير</p>
        <p className="signup-form__subtitle">
          سجل حسابك الآن وساهم في بناء مدينة أفضل للجميع
        </p>
      </motion.header>

      <motion.div variants={itemVariants}>
        <Link to={ROUTES.HOME} className="auth-back-home-btn">
          <FiHome />
          الرجوع للصفحة الرئيسية
        </Link>
      </motion.div>

      <motion.form
        className="signup-form__body"
        onSubmit={handleSubmit}
        noValidate
        variants={containerVariants}
      >
        <motion.div className="signup-form__grid" variants={containerVariants}>
          <motion.div className="signup-form__field" variants={itemVariants}>
            <label htmlFor="fullName">الاسم الكامل</label>
            <input
              id="fullName"
              name="fullName"
              type="text"
              placeholder="مثال: أحمد محمد"
              value={formData.fullName}
              onChange={handleChange}
              autoComplete="name"
            />
          </motion.div>

          <motion.div className="signup-form__field" variants={itemVariants}>
            <label htmlFor="phone">رقم الهاتف</label>
            <input
              id="phone"
              name="phone"
              type="tel"
              placeholder="مثال: 0123456789"
              value={formData.phone}
              onChange={handleChange}
              autoComplete="tel"
            />
          </motion.div>

          <motion.div className="signup-form__field" variants={itemVariants}>
            <label htmlFor="email">البريد الإلكتروني</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="مثال: example@mail.com"
              value={formData.email}
              onChange={handleChange}
              autoComplete="email"
            />
          </motion.div>

          <motion.div className="signup-form__field" variants={itemVariants}>
            <label>المحافظة</label>

            <div
              className={`signup-city-dropdown ${
                isCityMenuOpen ? 'is-open' : ''
              }`}
            >
              <button
                type="button"
                className={`signup-city-dropdown__button ${
                  selectedCity ? 'is-selected' : ''
                }`}
                onClick={() => setIsCityMenuOpen((current) => !current)}
                aria-expanded={isCityMenuOpen}
                aria-label="اختيار المحافظة"
              >
                <span>{selectedCity?.label || 'اختر المحافظة'}</span>
                <FiChevronDown />
              </button>

              {isCityMenuOpen ? (
                <div className="signup-city-dropdown__menu">
                  {GOVERNORATE_OPTIONS.map((city) => {
                    const isActive = formData.city === city.value;

                    return (
                      <button
                        key={city.value}
                        type="button"
                        className={`signup-city-dropdown__item ${
                          isActive ? 'is-active' : ''
                        }`}
                        onClick={() => handleCitySelect(city)}
                      >
                        <span>{city.label}</span>
                        {isActive ? <FiCheck /> : null}
                      </button>
                    );
                  })}
                </div>
              ) : null}
            </div>
          </motion.div>

          <motion.div className="signup-form__field" variants={itemVariants}>
            <label htmlFor="password">كلمة المرور</label>
            <PasswordInput
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              autoComplete="new-password"
              isVisible={visiblePasswords.password}
              onToggleVisibility={() =>
                setVisiblePasswords((prev) => ({
                  ...prev,
                  password: !prev.password,
                }))
              }
            />
          </motion.div>

          <motion.div className="signup-form__field" variants={itemVariants}>
            <label htmlFor="confirmPassword">تأكيد كلمة المرور</label>
            <PasswordInput
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              autoComplete="new-password"
              isVisible={visiblePasswords.confirmPassword}
              onToggleVisibility={() =>
                setVisiblePasswords((prev) => ({
                  ...prev,
                  confirmPassword: !prev.confirmPassword,
                }))
              }
            />
          </motion.div>
        </motion.div>

        <motion.label className="signup-form__checkbox" variants={itemVariants}>
          <input
            type="checkbox"
            name="termsAccepted"
            checked={formData.termsAccepted}
            onChange={handleChange}
          />
          <span>أوافق على الشروط والأحكام</span>
        </motion.label>

        {errorMessages.length > 0 ? (
          <motion.div
            className="signup-form__error"
            role="alert"
            aria-live="polite"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <ul className="signup-form__error-list">
              {errorMessages.map((message, index) => (
                <li
                  key={`${message}-${index}`}
                  className="signup-form__error-item"
                >
                  {message}
                </li>
              ))}
            </ul>
          </motion.div>
        ) : null}

        <motion.button
          type="submit"
          className="signup-form__submit"
          disabled={isSubmitting}
          variants={itemVariants}
          whileHover={{ y: -2, scale: 1.01 }}
          whileTap={{ scale: 0.985 }}
        >
          {isSubmitting ? 'جاري إنشاء الحساب...' : 'إنشاء حساب جديد'}
        </motion.button>

        <motion.p className="signup-form__footer" variants={itemVariants}>
          لديك حساب بالفعل؟{' '}
          <Link to={ROUTES.LOGIN} className="signup-form__footer-link">
            سجل الدخول
          </Link>
        </motion.p>
      </motion.form>

      <motion.div variants={itemVariants}>
        <GoogleAuthSection dividerText="أو تابع باستخدام Google" />
      </motion.div>
    </motion.div>
  );
}

export default SignupForm;
