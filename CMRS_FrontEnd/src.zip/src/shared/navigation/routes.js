export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  SIGNUP: '/signup',
  COMPANY_LOGIN: '/company-login',
  FORGOT_PASSWORD: '/forgot-password',

  DASHBOARD: '/dashboard',
  ADD_REPORT: '/reports/new',
  REPORTS: '/reports',
  MY_REPORTS: '/my-reports',
  NEARBY_ISSUES: '/nearby-issues',
  NOTIFICATIONS: '/notifications',
  PROFILE: '/profile',

  ADMIN_DASHBOARD: '/admin',
  ADMIN_REVIEW_REPORTS: '/admin/reports/review',
  ADMIN_REPORT_DETAILS: '/admin/reports/review/:reportId',
  ADMIN_COMPANIES: '/admin/companies',
  ADMIN_COMPANY_REQUESTS: '/admin/companies/requests',
  ADMIN_ANALYTICS: '/admin/analytics',
  ADMIN_PROFILE: '/admin/profile',

  COMPANY_DASHBOARD: '/company',
  COMPANY_REPORTS: '/company/reports',
  COMPANY_TEAMS: '/company/teams',
  COMPANY_ANALYTICS: '/company/analytics',
  COMPANY_NOTIFICATIONS: '/company/notifications',
  COMPANY_PROFILE: '/company/profile',

  UNAUTHORIZED: '/unauthorized',
  NOT_FOUND: '*',
};