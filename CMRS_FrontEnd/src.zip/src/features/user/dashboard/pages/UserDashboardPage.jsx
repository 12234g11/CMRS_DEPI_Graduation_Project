import { createPortal } from 'react-dom';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  FiArrowLeft,
  FiEye,
  FiMapPin,
  FiPlus,
} from 'react-icons/fi';

import { useAuth } from '../../../auth/hooks/useAuth';
import PageHeader from '../../../../shared/components/ui/PageHeader';
import { ROUTES } from '../../../../shared/navigation';

import MapLegend from '../../../map/components/MapLegend';
import ReportsMap from '../../../map/components/ReportsMap';
import { reportMapLegend } from '../../../map/mocks/mapMockData';

import useNearbyIssueDistances from '../../nearby-issues/hooks/useNearbyIssueDistances';
import { nearbyIssues } from '../../nearby-issues/mocks/nearbyIssuesMockData';

import useUserReports from '../../reports/hooks/useUserReports';

import UserDashboardStats from '../components/UserDashboardStats';
import UserDashboardFilters from '../components/UserDashboardFilters';
import UserMapSelectedReportCard from '../components/UserMapSelectedReportCard';
import UserDashboardReportDetailsModal from '../components/UserDashboardReportDetailsModal';

import '../user-dashboard.css';

const SOURCE_OPTIONS = [
  { value: 'all', label: 'كل البلاغات' },
  { value: 'mine', label: 'بلاغاتي' },
  { value: 'nearby', label: 'بلاغات قريبة مني' },
];

const STATUS_OPTIONS = [
  { value: 'all', label: 'كل الحالات' },
  { value: 'warning', label: 'قيد المراجعة' },
  { value: 'info', label: 'جاري الحل' },
  { value: 'success', label: 'تم الحل' },
];

function normalizeText(value) {
  return String(value || '').toLowerCase().trim();
}

function getReportPosition(report, userReportMarkers = []) {
  if (report?.position?.lat && report?.position?.lng) {
    return report.position;
  }

  const matchedMarker = userReportMarkers.find((marker) => {
    return (
      String(marker.id) === String(report.id) ||
      String(marker.reportId) === String(report.id) ||
      String(marker.originalId) === String(report.id) ||
      String(marker.id) === `report-${report.id}` ||
      String(marker.id) === `mine-${report.id}`
    );
  });

  return matchedMarker?.position || null;
}

function toUserDashboardReport(report, userReportMarkers = []) {
  const position = getReportPosition(report, userReportMarkers);

  return {
    id: `mine-${report.id}`,
    originalId: report.id,
    source: 'mine',

    reportNumber: report.reportNumber,
    title: report.title || report.issue || report.categoryLabel || 'بلاغ المستخدم',
    typeLabel: report.categoryLabel || report.issue || report.typeLabel || 'أخرى',

    statusLabel: report.statusLabel || 'قيد المراجعة',
    statusTone: report.statusTone || report.tone || 'warning',

    priority: report.severityLabel || report.priority || 'متوسطة',
    description: report.description || 'لا يوجد وصف متاح لهذا البلاغ.',

    area: report.area || report.city || '',
    address: report.locationText || report.address || report.area || report.city || '',

    date: report.createdAt || report.date || report.reportedAt,

    distance: '',
    distanceLabel: '',

    rating: report.rating || 0,
    coverImage: report.coverImage || report.image || '',
    images: report.images || [],

    position,
  };
}

function toNearbyDashboardReport(issue) {
  return {
    id: `nearby-${issue.id}`,
    originalId: issue.id,
    source: 'nearby',

    reportNumber: issue.reportNumber,
    title: issue.title || 'بلاغ قريب منك',
    typeLabel: issue.category || issue.type || issue.subtitle || 'أخرى',

    statusLabel: issue.statusLabel || 'قيد المراجعة',
    statusTone: issue.tone || issue.statusTone || 'warning',

    priority: issue.priority || 'متوسطة',
    description: issue.description || 'لا يوجد وصف متاح لهذا البلاغ.',

    area: issue.area || '',
    address: issue.address || issue.area || '',

    date: issue.reportedAt || issue.createdAt || issue.date,

    distance: issue.distance,
    distanceLabel: issue.distanceLabel,

    rating: issue.rating || 0,
    coverImage: issue.coverImage || issue.image || '',
    images: issue.images || [],

    position: issue.position,
  };
}

function buildMapMarker(report) {
  return {
    id: report.id,
    reportId: report.id,
    title: report.title,
    subtitle: report.typeLabel,
    area: report.area,
    statusLabel: report.statusLabel,
    tone: report.statusTone,
    distance: report.distance,
    distanceLabel: report.distanceLabel,
    address: report.address,
    position: report.position,
  };
}

function UserDashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const mapSectionRef = useRef(null);
  const selectedReportCardRef = useRef(null);

  const {
    recentReports = [],
    dashboardStats = [],
    mapMarkers: userReportMarkers = [],
  } = useUserReports(user?.id);

  const [currentLocation, setCurrentLocation] = useState(null);

  const nearbyIssuesWithAccurateDistances = useNearbyIssueDistances(
    nearbyIssues,
    currentLocation
  );

  const [searchTerm, setSearchTerm] = useState('');
  const [sourceFilter, setSourceFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const [activeMarkerId, setActiveMarkerId] = useState(null);
  const [selectedReport, setSelectedReport] = useState(null);
  const [detailsReport, setDetailsReport] = useState(null);
  const [routeReportId, setRouteReportId] = useState(null);

  const [followedReports, setFollowedReports] = useState(() => new Set());
  const [reportRatings, setReportRatings] = useState({});

  const focusMapReport = location.state?.focusMapReport || null;

  const dashboardReports = useMemo(() => {
    const userReportsForMap = recentReports
      .map((report) => toUserDashboardReport(report, userReportMarkers))
      .filter((report) => report.position?.lat && report.position?.lng);

    const nearbyReportsForMap = nearbyIssuesWithAccurateDistances
      .map(toNearbyDashboardReport)
      .filter((report) => report.position?.lat && report.position?.lng);

    const reports = [...userReportsForMap, ...nearbyReportsForMap];

    if (
      focusMapReport?.markerId &&
      focusMapReport?.position?.lat &&
      focusMapReport?.position?.lng &&
      !reports.some((report) => report.id === focusMapReport.markerId)
    ) {
      reports.unshift({
        id: focusMapReport.markerId,
        originalId: focusMapReport.originalId || focusMapReport.markerId,
        source: focusMapReport.source || 'mine',

        reportNumber: focusMapReport.reportNumber,
        title: focusMapReport.title || 'بلاغ المستخدم',
        typeLabel: focusMapReport.typeLabel || focusMapReport.subtitle || 'أخرى',

        statusLabel: focusMapReport.statusLabel || 'قيد المراجعة',
        statusTone: focusMapReport.tone || focusMapReport.statusTone || 'warning',

        priority: focusMapReport.priority || 'متوسطة',
        description:
          focusMapReport.description || 'لا يوجد وصف متاح لهذا البلاغ.',

        area: focusMapReport.area || '',
        address: focusMapReport.address || focusMapReport.area || '',

        date: focusMapReport.date || focusMapReport.createdAt,

        distance: focusMapReport.distance,
        distanceLabel: focusMapReport.distanceLabel,

        rating: focusMapReport.rating || 0,
        coverImage: focusMapReport.coverImage || '',
        images: focusMapReport.images || [],

        position: focusMapReport.position,
      });
    }

    return reports;
  }, [
    focusMapReport,
    nearbyIssuesWithAccurateDistances,
    recentReports,
    userReportMarkers,
  ]);

  const filteredReports = useMemo(() => {
    const query = normalizeText(searchTerm);

    return dashboardReports.filter((report) => {
      const matchesSource =
        sourceFilter === 'all' || report.source === sourceFilter;

      const matchesStatus =
        statusFilter === 'all' || report.statusTone === statusFilter;

      const searchableText = [
        report.id,
        report.originalId,
        report.reportNumber,
        report.title,
        report.typeLabel,
        report.area,
        report.address,
        report.statusLabel,
        report.priority,
      ]
        .map(normalizeText)
        .join(' ');

      const matchesSearch = !query || searchableText.includes(query);

      return matchesSource && matchesStatus && matchesSearch;
    });
  }, [dashboardReports, searchTerm, sourceFilter, statusFilter]);

  const mapMarkers = useMemo(() => {
    return filteredReports.map(buildMapMarker);
  }, [filteredReports]);

  const routeDestination = useMemo(() => {
    return (
      dashboardReports.find((report) => report.id === routeReportId) || null
    );
  }, [dashboardReports, routeReportId]);

  useEffect(() => {
    if (!focusMapReport?.markerId) return;

    const report = dashboardReports.find(
      (item) => item.id === focusMapReport.markerId
    );

    if (!report) return;

    setRouteReportId(null);
    setActiveMarkerId(report.id);
    setSelectedReport(report);

    const timer = window.setTimeout(() => {
      mapSectionRef.current?.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }, 150);

    return () => window.clearTimeout(timer);
  }, [dashboardReports, focusMapReport]);

  useEffect(() => {
    if (!selectedReport) return;

    const isMobile = window.matchMedia('(max-width: 768px)').matches;

    if (!isMobile) return;

    const timer = window.setTimeout(() => {
      selectedReportCardRef.current?.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }, 180);

    return () => window.clearTimeout(timer);
  }, [selectedReport]);

  function handleMarkerSelect(marker) {
    if (!marker?.id) return;

    const report = filteredReports.find(
      (item) =>
        String(item.id) === String(marker.id) ||
        String(item.id) === String(marker.reportId)
    );

    setRouteReportId(null);
    setActiveMarkerId(marker.id);
    setSelectedReport(report || null);
  }

  function handleResetFilters() {
    setSearchTerm('');
    setSourceFilter('all');
    setStatusFilter('all');
    setActiveMarkerId(null);
    setSelectedReport(null);
    setDetailsReport(null);
    setRouteReportId(null);
  }

  function handleToggleFollow(report) {
    if (!report?.id) return;

    setFollowedReports((current) => {
      const next = new Set(current);

      if (next.has(report.id)) {
        next.delete(report.id);
      } else {
        next.add(report.id);
      }

      return next;
    });
  }

  function handleRate(report) {
    if (!report?.id) return;

    setReportRatings((current) => ({
      ...current,
      [report.id]: (current[report.id] || report.rating || 0) + 1,
    }));
  }

  function handleRequestDirections(report) {
    if (!report?.id) return;

    if (!currentLocation?.lat || !currentLocation?.lng) {
      window.alert(
        'حدد موقعك الحالي من زر الخريطة أولًا، ثم اضغط أقصر مسافة.'
      );
      return;
    }

    setSelectedReport(report);
    setActiveMarkerId(report.id);
    setRouteReportId(report.id);
  }

  function handleGoToReport(report) {
    if (!report) return;

    if (report.source === 'mine') {
      navigate(ROUTES.MY_REPORTS, {
        state: {
          selectedReportId: report.originalId,
          highlightReportId: report.originalId,
        },
      });

      return;
    }

    navigate(ROUTES.NEARBY_ISSUES, {
      state: {
        selectedIssueId: report.originalId,
        highlightIssueId: report.originalId,
      },
    });
  }

  function renderPopupContent(marker) {
    const report = filteredReports.find(
      (item) => String(item.id) === String(marker.id)
    );

    if (!report) return null;

    return (
      <div className="user-dashboard-map-popup">
        <strong>{report.title}</strong>

        <span>{report.typeLabel}</span>

        <small>
          <FiMapPin />
          {report.area || report.address}
        </small>

        {report.distanceLabel ? <small>{report.distanceLabel}</small> : null}

        <div className="user-dashboard-map-popup__actions">
          <button
            type="button"
            onClick={() => {
              setSelectedReport(report);
              setDetailsReport(report);
            }}
          >
            <FiEye />
            عرض التفاصيل
          </button>

          <button type="button" onClick={() => handleGoToReport(report)}>
            صفحة البلاغ
            <FiArrowLeft />
          </button>
        </div>
      </div>
    );
  }

  const selectedReportRating = selectedReport
    ? reportRatings[selectedReport.id] || selectedReport.rating || 0
    : 0;

  const detailsReportRating = detailsReport
    ? reportRatings[detailsReport.id] || detailsReport.rating || 0
    : 0;

  return (
    <div className="dashboard-page user-dashboard-page">
      <PageHeader
        title="الصفحة الرئيسية"
        subtitle={`Dashboard — نظام إدارة البلاغات${
          user?.name || user?.userName
            ? ` • أهلاً ${user.name || user.userName}`
            : ''
        }`}
        action={
          <Link
            to={ROUTES.ADD_REPORT}
            className="dashboard-action-btn dashboard-action-btn--primary"
          >
            <FiPlus />
            <span>إضافة بلاغ</span>
          </Link>
        }
      />

      <UserDashboardStats stats={dashboardStats} />

      <UserDashboardFilters
        totalReports={dashboardReports.length}
        filteredCount={filteredReports.length}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        sourceFilter={sourceFilter}
        onSourceFilterChange={setSourceFilter}
        statusFilter={statusFilter}
        onStatusFilterChange={setStatusFilter}
        sourceOptions={SOURCE_OPTIONS}
        statusOptions={STATUS_OPTIONS}
        onReset={handleResetFilters}
      />

      <section ref={mapSectionRef} className="user-dashboard-map-card">
        <header className="user-dashboard-map-card__header">
          <div>
            <h2>خريطة البلاغات</h2>
            <p>
              اضغط على أي بلاغ على الخريطة لعرض ملخص سريع أو فتح التفاصيل.
            </p>
          </div>

          <div className="user-dashboard-map-card__actions">
            <MapLegend items={reportMapLegend} compact />
          </div>
        </header>

        <div className="user-dashboard-map-wrapper">
          <ReportsMap
            markers={mapMarkers}
            userLocation={user?.location}
            activeMarkerId={activeMarkerId}
            onMarkerSelect={handleMarkerSelect}
            onCurrentLocationChange={setCurrentLocation}
            routeDestination={routeDestination}
            height={620}
            renderPopupContent={renderPopupContent}
          />

          <div
            ref={selectedReportCardRef}
            className="user-dashboard-selected-report-card-slot"
          >
            <UserMapSelectedReportCard
              report={selectedReport}
              isFollowed={
                selectedReport ? followedReports.has(selectedReport.id) : false
              }
              rating={selectedReportRating}
              onClose={() => {
                setSelectedReport(null);
                setActiveMarkerId(null);
                setRouteReportId(null);
              }}
              onOpenDetails={setDetailsReport}
              onGoToReport={handleGoToReport}
              onToggleFollow={handleToggleFollow}
              onRate={handleRate}
              onRequestDirections={handleRequestDirections}
            />
          </div>
        </div>
      </section>

      {detailsReport
        ? createPortal(
            <UserDashboardReportDetailsModal
              report={detailsReport}
              isFollowed={followedReports.has(detailsReport.id)}
              rating={detailsReportRating}
              onClose={() => setDetailsReport(null)}
              onGoToReport={handleGoToReport}
              onToggleFollow={handleToggleFollow}
              onRate={handleRate}
              onRequestDirections={handleRequestDirections}
            />,
            document.body
          )
        : null}
    </div>
  );
}

export default UserDashboardPage;