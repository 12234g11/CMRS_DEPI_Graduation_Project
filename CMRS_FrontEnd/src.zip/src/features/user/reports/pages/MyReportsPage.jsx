import { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import {
  FiCheckCircle,
  FiClock,
  FiFileText,
  FiTool,
} from 'react-icons/fi';

import DashboardSectionCard from '../../../../shared/components/dashboard/DashboardSectionCard';
import PageHeader from '../../../../shared/components/ui/PageHeader';
import { useAuth } from '../../../auth/hooks/useAuth';
import RecentReportsTable from '../components/RecentReportsTable';
import UserReportsFilters from '../components/UserReportsFilters';
import useUserReports from '../hooks/useUserReports';
import {
  getReportsByStatus,
  REPORT_STATUS_API_VALUES,
  searchReports,
} from '../api/userReportsApi';
import '../user-reports.css';

function isReportOwnedByUser(report, userId) {
  if (!userId) return false;

  return (
    report.isOwnedByCurrentUser === true ||
    String(report.ownerUserId || '') === String(userId)
  );
}

function paginateItems(items = [], pageNumber = 1, pageSize = 10) {
  const startIndex = (pageNumber - 1) * pageSize;

  return items.slice(startIndex, startIndex + pageSize);
}

function getClientPagination(items = [], pageNumber = 1, pageSize = 10) {
  const totalCount = items.length;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  const safePageNumber = Math.min(pageNumber, totalPages);

  return {
    totalCount,
    pageNumber: safePageNumber,
    pageSize,
    totalPages,
  };
}

function MyReportsPage() {
  const { user } = useAuth();
  const location = useLocation();

  const [pageNumber, setPageNumber] = useState(1);
  const [clientPageNumber, setClientPageNumber] = useState(1);

  const {
    reports,
    pagination,
    isLoading,
    errorMessage,
  } = useUserReports(user?.id, pageNumber);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState(REPORT_STATUS_API_VALUES.all);

  const [searchResults, setSearchResults] = useState([]);
  const [statusResults, setStatusResults] = useState([]);

  const [isSearching, setIsSearching] = useState(false);
  const [isStatusLoading, setIsStatusLoading] = useState(false);

  const [searchErrorMessage, setSearchErrorMessage] = useState('');
  const [statusErrorMessage, setStatusErrorMessage] = useState('');

  const highlightedReportId =
    location.state?.createdReportId ||
    location.state?.selectedReportId ||
    location.state?.highlightReportId ||
    null;

  const successMessage = location.state?.successMessage || '';

  const isSearchActive = Boolean(searchQuery.trim());
  const isStatusActive = statusFilter !== REPORT_STATUS_API_VALUES.all;

  useEffect(() => {
    if (!highlightedReportId) return;

    const timer = window.setTimeout(() => {
      document
        .querySelector(`[data-report-row-id="${highlightedReportId}"]`)
        ?.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
        });
    }, 200);

    return () => window.clearTimeout(timer);
  }, [highlightedReportId, reports]);

  useEffect(() => {
    if (!isStatusActive) {
      setStatusResults([]);
      setStatusErrorMessage('');
      setIsStatusLoading(false);
      setClientPageNumber(1);
      return undefined;
    }

    let isCanceled = false;

    async function loadByStatus() {
      try {
        setIsStatusLoading(true);
        setStatusErrorMessage('');

        const response = await getReportsByStatus(statusFilter);

        if (isCanceled) return;

        const userOnlyReports = response.items.filter((report) =>
          isReportOwnedByUser(report, user?.id)
        );

        setStatusResults(userOnlyReports);
        setClientPageNumber(1);
      } catch (error) {
        if (isCanceled) return;

        setStatusResults([]);
        setStatusErrorMessage(
          error?.message || 'تعذر فلترة البلاغات حسب الحالة حاليًا.'
        );
      } finally {
        if (!isCanceled) {
          setIsStatusLoading(false);
        }
      }
    }

    loadByStatus();

    return () => {
      isCanceled = true;
    };
  }, [isStatusActive, statusFilter, user?.id]);

  useEffect(() => {
    const term = searchQuery.trim();

    if (!term) {
      setSearchResults([]);
      setIsSearching(false);
      setSearchErrorMessage('');
      setClientPageNumber(1);
      return undefined;
    }

    let isCanceled = false;

    const timer = window.setTimeout(async () => {
      try {
        setIsSearching(true);
        setSearchErrorMessage('');

        const results = await searchReports(term);

        if (isCanceled) return;

        const userOnlyResults = results.filter((report) =>
          isReportOwnedByUser(report, user?.id)
        );

        setSearchResults(userOnlyResults);
        setClientPageNumber(1);
      } catch (error) {
        if (isCanceled) return;

        setSearchResults([]);
        setSearchErrorMessage(
          error?.message || 'تعذر البحث في البلاغات حاليًا.'
        );
      } finally {
        if (!isCanceled) {
          setIsSearching(false);
        }
      }
    }, 400);

    return () => {
      isCanceled = true;
      window.clearTimeout(timer);
    };
  }, [searchQuery, user?.id]);

  const filterOptions = [
    { value: REPORT_STATUS_API_VALUES.all, label: 'كل الحالات' },
    { value: REPORT_STATUS_API_VALUES.underReview, label: 'قيد المراجعة' },
    { value: REPORT_STATUS_API_VALUES.inProgress, label: 'جاري الحل' },
    { value: REPORT_STATUS_API_VALUES.resolved, label: 'تم الحل' },
  ];

  const reportSummary = useMemo(() => {
    return reports.reduce(
      (summary, report) => {
        summary.total = pagination.totalCount || reports.length;

        if (report.statusKey === REPORT_STATUS_API_VALUES.underReview) {
          summary.pending += 1;
        }

        if (report.statusKey === REPORT_STATUS_API_VALUES.inProgress) {
          summary.inProgress += 1;
        }

        if (report.statusKey === REPORT_STATUS_API_VALUES.resolved) {
          summary.solved += 1;
        }

        return summary;
      },
      {
        total: pagination.totalCount || 0,
        pending: 0,
        inProgress: 0,
        solved: 0,
      }
    );
  }, [reports, pagination.totalCount]);

  const sourceReports = useMemo(() => {
    if (isSearchActive) {
      return searchResults.filter((report) => {
        if (!isStatusActive) return true;

        return report.statusKey === statusFilter;
      });
    }

    if (isStatusActive) {
      return statusResults;
    }

    return reports;
  }, [
    isSearchActive,
    searchResults,
    isStatusActive,
    statusFilter,
    statusResults,
    reports,
  ]);

  const pageSize = pagination.pageSize || 10;

  const clientPagination = useMemo(() => {
    return getClientPagination(sourceReports, clientPageNumber, pageSize);
  }, [sourceReports, clientPageNumber, pageSize]);

  const displayedReports = useMemo(() => {
    if (!isSearchActive && !isStatusActive) {
      return sourceReports;
    }

    return paginateItems(
      sourceReports,
      clientPagination.pageNumber,
      clientPagination.pageSize
    );
  }, [sourceReports, isSearchActive, isStatusActive, clientPagination]);

  const tablePagination =
    isSearchActive || isStatusActive ? clientPagination : pagination;

  const emptyMessage =
    isLoading || isStatusLoading
      ? 'جاري تحميل البلاغات...'
      : isSearching
        ? 'جاري البحث في البلاغات...'
        : isSearchActive || isStatusActive
          ? 'لا توجد بلاغات مطابقة لعملية البحث أو الفلترة.'
          : 'لم تقم بإضافة أي بلاغ حتى الآن.';

  function handleSearchChange(value) {
    setSearchQuery(value);
    setClientPageNumber(1);
  }

  function handleStatusFilterChange(value) {
    setStatusFilter(value);
    setClientPageNumber(1);
  }

  function handleResetFilters() {
    setSearchQuery('');
    setStatusFilter(REPORT_STATUS_API_VALUES.all);
    setSearchResults([]);
    setStatusResults([]);
    setSearchErrorMessage('');
    setStatusErrorMessage('');
    setClientPageNumber(1);
    setPageNumber(1);
  }

  function handleTablePageChange(nextPageNumber) {
    if (isSearchActive || isStatusActive) {
      setClientPageNumber(nextPageNumber);
      return;
    }

    setPageNumber(nextPageNumber);
  }

  return (
    <div className="dashboard-page">
      <PageHeader
        title="بلاغاتي"
        subtitle="متابعة كل البلاغات الخاصة بك في مكان واحد"
      />

      {successMessage ? (
        <div className="user-reports__success-banner">
          {successMessage}
        </div>
      ) : null}

      {errorMessage ? (
        <div className="user-reports__success-banner user-reports__success-banner--error">
          {errorMessage}
        </div>
      ) : null}

      {searchErrorMessage ? (
        <div className="user-reports__success-banner user-reports__success-banner--error">
          {searchErrorMessage}
        </div>
      ) : null}

      {statusErrorMessage ? (
        <div className="user-reports__success-banner user-reports__success-banner--error">
          {statusErrorMessage}
        </div>
      ) : null}

      <div className="user-reports-summary-grid" dir="rtl">
        <div className="user-reports-summary-card user-reports-summary-card--total">
          <div className="user-reports-summary-card__content">
            <h3>البلاغات المقدمة</h3>
            <p>Total Reports</p>
            <strong>{reportSummary.total}</strong>
          </div>

          <span className="user-reports-summary-card__icon">
            <FiFileText />
          </span>
        </div>

        <div className="user-reports-summary-card user-reports-summary-card--pending">
          <div className="user-reports-summary-card__content">
            <h3>قيد المراجعة</h3>
            <p>Pending</p>
            <strong>{reportSummary.pending}</strong>
          </div>

          <span className="user-reports-summary-card__icon">
            <FiClock />
          </span>
        </div>

        <div className="user-reports-summary-card user-reports-summary-card--progress">
          <div className="user-reports-summary-card__content">
            <h3>جاري الحل</h3>
            <p>In Progress</p>
            <strong>{reportSummary.inProgress}</strong>
          </div>

          <span className="user-reports-summary-card__icon">
            <FiTool />
          </span>
        </div>

        <div className="user-reports-summary-card user-reports-summary-card--solved">
          <div className="user-reports-summary-card__content">
            <h3>تم الحل</h3>
            <p>Solved</p>
            <strong>{reportSummary.solved}</strong>
          </div>

          <span className="user-reports-summary-card__icon">
            <FiCheckCircle />
          </span>
        </div>
      </div>

      <UserReportsFilters
        totalReports={sourceReports.length}
        filteredCount={displayedReports.length}
        searchQuery={searchQuery}
        onSearchChange={handleSearchChange}
        statusFilter={statusFilter}
        onStatusFilterChange={handleStatusFilterChange}
        statusOptions={filterOptions}
        onReset={handleResetFilters}
        isSearching={isSearching || isStatusLoading}
      />

      <DashboardSectionCard
        title={isSearchActive || isStatusActive ? 'نتائج البحث' : 'كل البلاغات'}
        subtitle={isSearchActive || isStatusActive ? 'Search Results' : 'All Reports'}
      >
        <RecentReportsTable
          reports={displayedReports}
          highlightedReportId={highlightedReportId}
          emptyMessage={emptyMessage}
          pagination={tablePagination}
          onPageChange={handleTablePageChange}
          isLoading={isLoading || isSearching || isStatusLoading}
        />
      </DashboardSectionCard>
    </div>
  );
}

export default MyReportsPage;