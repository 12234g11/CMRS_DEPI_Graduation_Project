import axiosClient from '../../../../shared/services/api/axiosClient';
import { resolveAssetUrl } from '../../../../shared/services/api/assetUrl';

export const REPORT_STATUS_API_VALUES = {
  all: 'all',
  underReview: 'UnderReview',
  inProgress: 'InProgress',
  resolved: 'Resolved',
};

function getApiErrorMessage(error) {
  const data = error?.response?.data;

  if (!data) {
    return error?.message || 'حدث خطأ غير متوقع.';
  }

  if (typeof data === 'string') {
    return data;
  }

  const errors = data.errors || data.Errors;

  if (errors && typeof errors === 'object') {
    const messages = Object.entries(errors)
      .filter(([key]) => String(key).toLowerCase() !== 'traceid')
      .flatMap(([field, value]) => {
        if (Array.isArray(value)) {
          return value.map((message) => `${field}: ${message}`);
        }

        if (typeof value === 'string') {
          return [`${field}: ${value}`];
        }

        return [];
      });

    if (messages.length) {
      return messages.join(' ');
    }
  }

  return (
    data.message ||
    data.Message ||
    data.title ||
    data.Title ||
    'حدث خطأ أثناء تحميل البلاغات.'
  );
}

function getResponseData(response) {
  return response?.data?.data || response?.data?.Data || response?.data;
}

function getStatusTone(status = '') {
  const value = String(status || '').toLowerCase();

  if (value === 'resolved') {
    return 'success';
  }

  if (value === 'inprogress') {
    return 'info';
  }

  if (value === 'rejected') {
    return 'danger';
  }

  return 'warning';
}

function getReportStatusKey(status = '') {
  const value = String(status || '').toLowerCase();

  if (value === 'resolved') {
    return 'Resolved';
  }

  if (value === 'inprogress') {
    return 'InProgress';
  }

  return 'UnderReview';
}

function buildAreaText(area = {}) {
  return [area.city, area.address, area.detailedAddress]
    .filter(Boolean)
    .join(' - ');
}

function prepareReportForUi(report = {}) {
  const reportImages = Array.isArray(report.reportImages)
    ? report.reportImages.map((image) => ({
        ...image,
        imageUrl: image.imageUrl || '',
        fullImageUrl: resolveAssetUrl(image.imageUrl || ''),
      }))
    : [];

  const imageUrls = reportImages
    .map((image) => image.fullImageUrl)
    .filter(Boolean);

  const areaText = buildAreaText(report.area || {});

  return {
    ...report,

    id: report.reportId,
    categoryLabel: report.issueCategoryName,

    statusTone: getStatusTone(report.status),
    statusKey: getReportStatusKey(report.status),

    areaText,
    locationText: areaText,

    imageUrls,
    images: imageUrls,
    coverImage: imageUrls[0] || '',

    position:
      Number.isFinite(Number(report.latitude)) &&
      Number.isFinite(Number(report.longitude))
        ? {
            lat: Number(report.latitude),
            lng: Number(report.longitude),
          }
        : null,
  };
}

function extractReportsPage(response) {
  const data = getResponseData(response);

  if (Array.isArray(data)) {
    return {
      items: data.map(prepareReportForUi),
      totalCount: data.length,
      pageNumber: 1,
      pageSize: data.length || 10,
      totalPages: 1,
    };
  }

  const items = Array.isArray(data?.items) ? data.items : [];

  return {
    items: items.map(prepareReportForUi),
    totalCount: Number(data?.totalCount ?? items.length),
    pageNumber: Number(data?.pageNumber ?? 1),
    pageSize: Number(data?.pageSize ?? 10),
    totalPages: Number(data?.totalPages ?? 1),
  };
}

export async function getUserReports(input = {}) {
  const userId = typeof input === 'string' ? input : input.userId;
  const pageNumber = typeof input === 'string' ? 1 : input.pageNumber || 1;

  if (!userId) {
    return {
      items: [],
      totalCount: 0,
      pageNumber: 1,
      pageSize: 10,
      totalPages: 1,
    };
  }

  try {
    const response = await axiosClient.get(
      `/api/Report/user/${encodeURIComponent(userId)}`,
      {
        params: {
          pageNumber,
        },
      }
    );

    return extractReportsPage(response);
  } catch (error) {
    throw new Error(getApiErrorMessage(error));
  }
}

export async function getReportsByStatus(status) {
  const apiStatus = String(status || '').trim();

  if (!apiStatus || apiStatus === REPORT_STATUS_API_VALUES.all) {
    return {
      items: [],
      totalCount: 0,
      pageNumber: 1,
      pageSize: 10,
      totalPages: 1,
    };
  }

  try {
    const response = await axiosClient.get(
      `/api/Report/Status/${encodeURIComponent(apiStatus)}`
    );

    return extractReportsPage(response);
  } catch (error) {
    throw new Error(getApiErrorMessage(error));
  }
}

export async function searchReports(searchTerm = '') {
  const term = String(searchTerm || '').trim();

  if (!term) {
    return [];
  }

  try {
    const response = await axiosClient.get('/api/Report/search', {
      params: {
        term,
      },
    });

    const data = getResponseData(response);
    const items = Array.isArray(data) ? data : [];

    return items.map(prepareReportForUi);
  } catch (error) {
    throw new Error(getApiErrorMessage(error));
  }
}